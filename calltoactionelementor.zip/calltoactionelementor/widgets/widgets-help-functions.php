<?php
/** Get Animations **/
if(!function_exists('calltoaction_animate_class')) {
	function calltoaction_animate_class($addon_animate,$effect,$delay) {
		if($addon_animate == 'on') : 
			wp_enqueue_script( 'appear' );			
			wp_enqueue_script( 'animate' );		
			$animate_class = ' animate-in" data-anim-type="'.$effect.'" data-anim-delay="'.$delay.'"'; 
		else :
			$animate_class = '"';
		endif;		
		return $animate_class;
	}
}