<?php
namespace ElementorCalltoaction\Widgets;

use \Elementor\Controls_Manager as Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Group_Control_Border as Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow as Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography as Group_Control_Typography;
use \Elementor\Utils as Utils;
use \Elementor\Widget_Base as Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Calltoaction
 *
 * Elementor widget for team vision
 *
 * @since 1.0.0
 */
class Calltoaction extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'calltoaction';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Call to Action', 'elementor-calltoaction' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-call-to-action';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'elementor-calltoaction' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'elementor-calltoaction' ),
			]
		);

		$this->add_control(
			'button_type',
			[
				'label' => esc_html__( 'Call to Action Type', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'flat-button-mini',
				'options' => [
					'flat-button-mini'		=> esc_html__( 'Flat Mini', 'elementor-calltoaction' ),
					'flat-button-small'		=> esc_html__( 'Flat Small', 'elementor-calltoaction' ),
					'flat-button-medium'	=> esc_html__( 'Flat Medium', 'elementor-calltoaction' ),
					'flat-button-large'		=> esc_html__( 'Flat Large', 'elementor-calltoaction' ),
					'bg-none-button-mini'	=> esc_html__( 'Backgraund Transparent Mini', 'elementor-calltoaction' ),
					'bg-none-button-small'	=> esc_html__( 'Backgraund Transparent Small', 'elementor-calltoaction' ),
					'bg-none-button-medium'	=> esc_html__( 'Backgraund Transparent Medium', 'elementor-calltoaction' ),
					'bg-none-button-large'	=> esc_html__( 'Backgraund Transparent Large', 'elementor-calltoaction' ),
					'd-button-mini'			=> esc_html__( '3D Mini', 'elementor-calltoaction' ),
					'd-button-small'		=> esc_html__( '3D Small', 'elementor-calltoaction' ),
					'd-button-medium'		=> esc_html__( '3D Medium', 'elementor-calltoaction' ),
					'd-button-large'		=> esc_html__( '3D Large', 'elementor-calltoaction' ),
					'button-custom'			=> esc_html__( 'Custom', 'elementor-calltoaction' )				
				]
			]
		);		

		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Text', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Call to Action Text'
			]
		);

		$this->add_control(
			'button_url',
			[
				'label' => esc_html__( 'Url Button (ex http://www.google.com)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true
			]
		);

		$this->add_control(
			'button_target_url',
			[
				'label' => esc_html__( 'Target Button', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => '_self',
				'options' => [
					'_self'		=> esc_html__( 'Self (Same Window)', 'elementor-calltoaction' ),
					'_blank'	=> esc_html__( 'Blank (New Window)', 'elementor-calltoaction' )				]
			]
		);	

		$this->add_control(
			'button_icon_show',
			[
				'label' => esc_html__( 'Icon Show', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'calltoaction-icon-hidden',
				'options' => [
					'calltoaction-icon-hidden'	=> esc_html__( 'Hidden', 'elementor-calltoaction' ),
					'calltoaction-icon-show'	=> esc_html__( 'Show', 'elementor-calltoaction' )				]
			]
		);	

		$this->add_control(
			'button_icon',
			[
				'label' => esc_html__( 'Icon', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
						'value' => 'fas fa-star',
						'library' => 'solid',
				],
				'condition'	=> [
					'button_icon_show'	=> 'calltoaction-icon-show'
				]
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_animation',
			[
				'label' => esc_html__( 'Animations', 'elementor-calltoaction' )
			]
		);
		
		$this->add_control(
			'addon_animate',
			[
				'label' => esc_html__( 'Animate', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'off',
				'options' => [
					'off'	=> 'Off',
					'on' 	=> 'On'					
				]
			]
		);		

		$this->add_control(
			'effect',
			[
				'label' => esc_html__( 'Animate Effects', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'fade-in',
				'options' => [
							'fade-in'			=> esc_html__( 'Fade In', 'elementor-calltoaction' ),
							'fade-in-up' 		=> esc_html__( 'fade in up', 'elementor-calltoaction' ),					
							'fade-in-down' 		=> esc_html__( 'fade in down', 'elementor-calltoaction' ),					
							'fade-in-left' 		=> esc_html__( 'fade in Left', 'elementor-calltoaction' ),					
							'fade-in-right' 	=> esc_html__( 'fade in Right', 'elementor-calltoaction' ),					
							'fade-out'			=> esc_html__( 'Fade In', 'elementor-calltoaction' ),
							'fade-out-up' 		=> esc_html__( 'Fade Out up', 'elementor-calltoaction' ),					
							'fade-out-down' 	=> esc_html__( 'Fade Out down', 'elementor-calltoaction' ),					
							'fade-out-left' 	=> esc_html__( 'Fade Out Left', 'elementor-calltoaction' ),					
							'fade-out-right' 	=> esc_html__( 'Fade Out Right', 'elementor-calltoaction' ),
							'bounce-in'			=> esc_html__( 'Bounce In', 'elementor-calltoaction' ),
							'bounce-in-up' 		=> esc_html__( 'Bounce in up', 'elementor-calltoaction' ),					
							'bounce-in-down' 	=> esc_html__( 'Bounce in down', 'elementor-calltoaction' ),					
							'bounce-in-left' 	=> esc_html__( 'Bounce in Left', 'elementor-calltoaction' ),					
							'bounce-in-right' 	=> esc_html__( 'Bounce in Right', 'elementor-calltoaction' ),					
							'bounce-out'		=> esc_html__( 'Bounce In', 'elementor-calltoaction' ),
							'bounce-out-up' 	=> esc_html__( 'Bounce Out up', 'elementor-calltoaction' ),					
							'bounce-out-down' 	=> esc_html__( 'Bounce Out down', 'elementor-calltoaction' ),					
							'bounce-out-left' 	=> esc_html__( 'Bounce Out Left', 'elementor-calltoaction' ),					
							'bounce-out-right' 	=> esc_html__( 'Bounce Out Right', 'elementor-calltoaction' ),	
							'zoom-in'			=> esc_html__( 'Zoom In', 'elementor-calltoaction' ),
							'zoom-in-up' 		=> esc_html__( 'Zoom in up', 'elementor-calltoaction' ),					
							'zoom-in-down' 		=> esc_html__( 'Zoom in down', 'elementor-calltoaction' ),					
							'zoom-in-left' 		=> esc_html__( 'Zoom in Left', 'elementor-calltoaction' ),					
							'zoom-in-right' 	=> esc_html__( 'Zoom in Right', 'elementor-calltoaction' ),					
							'zoom-out'			=> esc_html__( 'Zoom In', 'elementor-calltoaction' ),
							'zoom-out-up' 		=> esc_html__( 'Zoom Out up', 'elementor-calltoaction' ),					
							'zoom-out-down' 	=> esc_html__( 'Zoom Out down', 'elementor-calltoaction' ),					
							'zoom-out-left' 	=> esc_html__( 'Zoom Out Left', 'elementor-calltoaction' ),					
							'zoom-out-right' 	=> esc_html__( 'Zoom Out Right', 'elementor-calltoaction' ),
							'flash' 			=> esc_html__( 'Flash', 'elementor-calltoaction' ),
							'strobe'			=> esc_html__( 'Strobe', 'elementor-calltoaction' ),
							'shake-x'			=> esc_html__( 'Shake X', 'elementor-calltoaction' ),
							'shake-y'			=> esc_html__( 'Shake Y', 'elementor-calltoaction' ),
							'bounce' 			=> esc_html__( 'Bounce', 'elementor-calltoaction' ),
							'tada'				=> esc_html__( 'Tada', 'elementor-calltoaction' ),
							'rubber-band'		=> esc_html__( 'Rubber Band', 'elementor-calltoaction' ),
							'swing' 			=> esc_html__( 'Swing', 'elementor-calltoaction' ),
							'spin'				=> esc_html__( 'Spin', 'elementor-calltoaction' ),
							'spin-reverse'		=> esc_html__( 'Spin Reverse', 'elementor-calltoaction' ),
							'slingshot'			=> esc_html__( 'Slingshot', 'elementor-calltoaction' ),
							'slingshot-reverse'	=> esc_html__( 'Slingshot Reverse', 'elementor-calltoaction' ),
							'wobble'			=> esc_html__( 'Wobble', 'elementor-calltoaction' ),
							'pulse' 			=> esc_html__( 'Pulse', 'elementor-calltoaction' ),
							'pulsate'			=> esc_html__( 'Pulsate', 'elementor-calltoaction' ),
							'heartbeat'			=> esc_html__( 'Heartbeat', 'elementor-calltoaction' ),
							'panic' 			=> esc_html__( 'Panic', 'elementor-calltoaction' )				
				],
				'condition'	=> [
					'addon_animate'	=> 'on'
				]
			]
		);			

		$this->add_control(
			'delay',
			[
				'label' => esc_html__( 'Animate Delay (ms)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => '1000',
				'condition'	=> [
					'addon_animate'	=> 'on'
				]
			]
		);	
		
		$this->end_controls_section();


		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style', 'elementor-calltoaction' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_font_type',
			[
				'label' => esc_html__( 'Font Type', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'calltoaction-font-default',
				'options' => [
					'calltoaction-font-default'	=> esc_html__( 'Default Site', 'elementor-calltoaction' ),
					'calltoaction-google-font' 	=> esc_html__( 'Google Fonts Custom', 'elementor-calltoaction' )				
				]
			]
		);

		$this->add_control(
			'google_fonts',
			[
				'label' => __( 'Google Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'condition'	=> [
					'button_font_type'	=> 'calltoaction-google-font'
				]
			]
		);

		$this->add_control(
			'button_size',
			[
				'label' => esc_html__( 'Text Size (px)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => '30px'
			]
		);

		$this->add_control(
			'button_align',
			[
				'label' => esc_html__( 'Text Align', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'calltoaction-align-center',
				'options' => [
					'calltoaction-align-center'	=> esc_html__( 'Center', 'elementor-calltoaction' ),
					'calltoaction-align-left' 		=> esc_html__( 'Left', 'elementor-calltoaction' ),				
					'calltoaction-align-right' 	=> esc_html__( 'Right', 'elementor-calltoaction' )				
				]
			]
		);

		$this->add_control(
			'button_custom_padding',
			[
				'label' => esc_html__( 'Padding (px)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => '15px',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->add_control(
			'button_custom_margin',
			[
				'label' => esc_html__( 'Margin (px)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => '15px',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->add_control(
			'button_custom_border_radius',
			[
				'label' => esc_html__( 'Border Radius (px)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => '15px',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->add_control(
			'button_display',
			[
				'label' => esc_html__( 'Display', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'block',
				'options' => [
					'block'			=> esc_html__( 'Block', 'elementor-calltoaction' ),
					'inline-block' 	=> esc_html__( 'Inline', 'elementor-calltoaction' )				
				]
			]
		);

		$this->add_control(
			'button_position',
			[
				'label' => esc_html__( 'Position', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'relative',
				'options' => [
					'relative'	=> esc_html__( 'Relative', 'elementor-calltoaction' ),
					'fixed' 	=> esc_html__( 'Fixed', 'elementor-calltoaction' )				
				]
			]
		);

		$this->add_control(
			'button_position_bt',
			[
				'label' => esc_html__( 'Position', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'bottom',
				'options' => [
					'bottom'	=> esc_html__( 'Bottom', 'elementor-calltoaction' ),
					'top' 		=> esc_html__( 'Top', 'elementor-calltoaction' )				
				],
				'condition'	=> [
					'button_position'	=> 'fixed'
				]
			]
		);

		$this->add_control(
			'button_fixed_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FC615D',
				'condition'	=> [
					'button_position'	=> 'fixed'
				]
			]
		);

		$this->add_control(
			'button_border_type',
			[
				'label' => esc_html__( 'Border Type', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'calltoaction-border-square',
				'options' => [
					'calltoaction-border-square'	=> esc_html__( 'Square', 'elementor-calltoaction' ),
					'calltoaction-border-round' 	=> esc_html__( 'Round', 'elementor-calltoaction' )				
				],
				'condition'	=> [
					'button_type'	=> array(
											'bg-none-button-mini', 
											'bg-none-button-small',
											'bg-none-button-medium',
											'bg-none-button-large',
											'flat-button-mini', 
											'flat-button-small',
											'flat-button-medium',
											'flat-button-large',							
											'd-button-mini', 
											'd-button-small',
											'd-button-medium',
											'd-button-large'																													
										)
				]
			]
		);


		$this->add_control(
			'button_border_style',
			[
				'label' => esc_html__( 'Border Style', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
					'solid'		=> esc_html__( 'Solid', 'elementor-calltoaction' ),
					'dotted' 	=> esc_html__( 'Dotted', 'elementor-calltoaction' ),				
					'dashed' 	=> esc_html__( 'Dashed', 'elementor-calltoaction' ),				
					'double' 	=> esc_html__( 'Double', 'elementor-calltoaction' ),				
					'inset' 	=> esc_html__( 'Inset', 'elementor-calltoaction' ),				
					'outset' 	=> esc_html__( 'Outset', 'elementor-calltoaction' )				
				],
				'condition'	=> [
					'button_type'	=> array(
											'bg-none-button-mini', 
											'bg-none-button-small',
											'bg-none-button-medium',
											'bg-none-button-large'																			
										)
				]
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FFFFFF'
			]
		);

		$this->add_control(
			'button_over_color',
			[
				'label' => esc_html__( 'Over Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FC615D',
				'condition'	=> [
					'button_type'	=> array(
											'bg-none-button-mini', 
											'bg-none-button-small',
											'bg-none-button-medium',
											'bg-none-button-large'																			
										)
				]
			]
		);

		$this->add_control(
			'button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FC615D',
				'condition'	=> [
					'button_type'	=> array( 
											'flat-button-mini', 
											'flat-button-small',
											'flat-button-medium',
											'flat-button-large',							
											'd-button-mini', 
											'd-button-small',
											'd-button-medium',
											'd-button-large',
											'button-custom',
										)
				]
			]
		);


		$this->add_control(
			'button_border_color',
			[
				'label' => esc_html__( 'Border Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FC615D',
				'condition'	=> [
					'button_type'	=> array(
											'bg-none-button-mini', 
											'bg-none-button-small',
											'bg-none-button-medium',
											'bg-none-button-large'																			
										)
				]
			]
		);


		$this->add_control(
			'button_custom_border_active',
			[
				'label' => esc_html__( 'Border Show', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'on',
				'options' => [
					'on'			=> esc_html__( 'On', 'elementor-calltoaction' ),
					'off' 	=> esc_html__( 'Off', 'elementor-calltoaction' )				
				],
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->add_control(
			'button_custom_border_width',
			[
				'label' => esc_html__( 'Border Width (px)', 'elementor-calltoaction' ),
				'type' => Controls_Manager::TEXT,
				'default' => '1px',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->add_control(
			'button_custom_border_color',
			[
				'label' => esc_html__( 'Border Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FC615D',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->add_control(
			'button_custom_border_style',
			[
				'label' => esc_html__( 'Border Style', 'elementor-calltoaction' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
					'solid'		=> esc_html__( 'Solid', 'elementor-calltoaction' ),
					'dotted' 	=> esc_html__( 'Dotted', 'elementor-calltoaction' ),				
					'dashed' 	=> esc_html__( 'Dashed', 'elementor-calltoaction' ),				
					'double' 	=> esc_html__( 'Double', 'elementor-calltoaction' ),				
					'inset' 	=> esc_html__( 'Inset', 'elementor-calltoaction' ),				
					'outset' 	=> esc_html__( 'Outset', 'elementor-calltoaction' )				
				],
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);
		
		$this->add_control(
			'button_custom_text_over_color',
			[
				'label' => esc_html__( 'Text Over Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FFFFFF',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);		
		
		$this->add_control(
			'button_custom_background_over_color',
			[
				'label' => esc_html__( 'Background Over Color', 'elementor-calltoaction' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FC615D',
				'condition'	=> [
					'button_type'	=> 'button-custom'
				]
			]
		);

		$this->end_controls_section();
		
	}

	 
	 /**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		static $instance = 0;
		$instance++;		
		$settings = $this->get_settings_for_display();
		
		$button_type 							= esc_html($settings['button_type']);	
		$button_text 							= esc_html($settings['button_text']);	
		$button_url 							= esc_html($settings['button_url']);
		$button_target_url 						= esc_html($settings['button_target_url']);
		$button_align 							= esc_html($settings['button_align']);
		$button_custom_padding 					= esc_html($settings['button_custom_padding']);
		$button_custom_margin 					= esc_html($settings['button_custom_margin']);
		$button_custom_border_radius 			= esc_html($settings['button_custom_border_radius']);
		$button_display 						= esc_html($settings['button_display']);
		$button_position 						= esc_html($settings['button_position']);
		$button_position_bt 					= esc_html($settings['button_position_bt']);
		$button_fixed_bg_color 					= esc_html($settings['button_fixed_bg_color']);
		$button_icon_show 						= esc_html($settings['button_icon_show']);
		$button_font_type 						= esc_html($settings['button_font_type']); 
		$google_fonts 							= esc_html($settings['google_fonts']);
		$button_size 							= esc_html($settings['button_size']);
		$button_text_color 						= esc_html($settings['button_text_color']);
		$button_over_color 						= esc_html($settings['button_over_color']);
		$button_background_color 				= esc_html($settings['button_background_color']);
		$button_border_color 					= esc_html($settings['button_border_color']);
		$button_border_type 					= esc_html($settings['button_border_type']);
		$button_border_style 					= esc_html($settings['button_border_style']);
		$button_custom_border_active 			= esc_html($settings['button_custom_border_active']);
		$button_custom_border_color 			= esc_html($settings['button_custom_border_color']);
		$button_custom_border_width 			= esc_html($settings['button_custom_border_width']);
		$button_custom_border_style 			= esc_html($settings['button_custom_border_style']);
		$button_custom_text_over_color 			= esc_html($settings['button_custom_text_over_color']);
		$button_custom_background_over_color 	= esc_html($settings['button_custom_background_over_color']);
		$addon_animate							= esc_html($settings['addon_animate']);
		$effect									= esc_html($settings['effect']);
		$delay									= esc_html($settings['delay']);

		wp_enqueue_script( 'calltoaction' );
		wp_enqueue_style( 'animations' );
		wp_enqueue_script( 'appear' );			
		wp_enqueue_script( 'animate' );

		$css_container_inline = $css_a_inline = 'style="';
		$css_i_inline = '';
		$css_style_to_append = '';
		
		// Google Fonts
		if($button_font_type == 'calltoaction-google-font') :
		
			$css_a_inline .= 'font-family: ' . $google_fonts . ';';   

		endif;
		
		$css_container_inline .= 'display:'.esc_html($button_display).';';
		$css_i_inline .= 'font-size:'.esc_html($button_size).';';				
		$css_a_inline .= 'font-size:'.esc_html($button_size).';';

		
		if(	$button_type == 'flat-button-mini' || 
			$button_type == 'flat-button-small' || 
			$button_type == 'flat-button-medium' || 
			$button_type == 'flat-button-large') :

			$css_a_inline .= 'color:'.esc_html($button_text_color).';
							  background:'.esc_html($button_background_color).';
							  border-color:'.esc_html($button_background_color).';
							  border-style:'.esc_html($button_border_style).';';


							  
			$css_style_to_append = '<style>
			.calltoaction-button.'.esc_html($button_type).'.calltoaction-button-'.esc_html($instance).' a:hover {
							color:'.esc_html($button_background_color).'!important;
							background:'.esc_html($button_text_color).'!important;
							border-color:'.esc_html($button_text_color).'!important; 
			}
			</style>';
		endif;

		if(	$button_type == 'bg-none-button-mini' || 
			$button_type == 'bg-none-button-small' || 
			$button_type == 'bg-none-button-medium' || 
			$button_type == 'bg-none-button-large') :

			$css_a_inline .= 'color:'.esc_html($button_text_color).';
							border-color:'.esc_html($button_text_color).';
							border-style:'.esc_html($button_border_style).';';
			
			
			$css_style_to_append = '<style>
					.calltoaction-button.'.esc_html($button_type).'.calltoaction-button-'.esc_html($instance).' a:hover {
						color:'.esc_html($button_over_color).'!important;
						border-color:'.esc_html($button_over_color).'!important;					
					}
			</style>';

		endif;
		
		if(	$button_type == 'd-button-mini' || 
			$button_type == 'd-button-small' || 
			$button_type == 'd-button-medium' || 
			$button_type == 'd-button-large') :							
			
			if($button_type == 'd-button-mini') { $shadow_size = '4'; }
			if($button_type == 'd-button-small') { $shadow_size = '6'; }
			if($button_type == 'd-button-medium') { $shadow_size = '8'; }
			if($button_type == 'd-button-large') { $shadow_size = '10'; }
			
			
			$css_a_inline .= 'color:'.esc_html($button_text_color).';
							background:'.esc_html($button_background_color).';
							box-shadow: 0 '.esc_html($shadow_size).'px 0 '.esc_html($button_border_color).';';
							
			$css_style_to_append = '<style>				
						.calltoaction-button.'.esc_html($button_type).'.calltoaction-button-'.esc_html($instance).' a:hover {
							box-shadow: 0 2px 0 '.esc_html($button_border_color).'!important;					
						}
			</style>';
		endif;		
		
		if($button_type == 'button-custom') {
			$css_a_inline .= '
							color:'.esc_html($button_text_color).';
							background:'.esc_html($button_background_color).';
							padding:'.esc_html($button_custom_padding).';
							margin:'.esc_html($button_custom_margin).';
							border-radius:'.esc_html($button_custom_border_radius).';
						';
			$css_style_to_append = '<style>				
						.calltoaction-button.'.esc_html($button_type).'.calltoaction-button-'.esc_html($instance).' a:hover {
							color:'.esc_html($button_custom_text_over_color).'!important;
							background:'.esc_html($button_custom_background_over_color).'!important;
							border-color:'.esc_html($button_text_color).'!important;					
						}
			</style>';
			
			if($button_custom_border_active == 'on') {
				$css_a_inline .= '
							border-color:'.esc_html($button_custom_border_color).';	
							border-width:'.esc_html($button_custom_border_width).';
							border-style:'.esc_html($button_custom_border_style).';			
				';
			}
		}		
		
		$position_button = $position_button_bt = '';
		if($button_position == 'fixed') {
			$position_button = 'calltoaction-fixed';
			$position_button_bt = 'calltoaction-fixed-'.esc_html($button_position_bt).'';
			$css_container_inline .= 'background:'.esc_html($button_fixed_bg_color).';';
		}
		
		$css_i_inline .= '';
		$css_container_inline .= '"';
		$css_a_inline .= '"';
		
		
		
		
		$data_value = 'data-calltoaction-custom-css="'.$css_style_to_append.'"';
		
				
		$inline_block = '';
		if($button_display == 'inline-block') {
			$inline_block .= 'calltoaction-inline-block';
		}		

		
		
		
		echo '<span '.$css_container_inline.' '.$data_value.' class="calltoaction-button calltoaction-custom-js '.esc_html($button_type).' '.esc_html($inline_block).' '.esc_html($position_button).' '.esc_html($position_button_bt).' '.esc_html($button_border_type).' '.esc_html($button_align).' calltoaction-button-'.esc_html($instance).calltoaction_animate_class($addon_animate,$effect,$delay).'>';
			echo '<a '.$css_a_inline.' href="'.esc_url($button_url).'" target="'.esc_html($button_target_url).'">';
				
			if($button_icon_show == 'calltoaction-icon-show') {
				//echo '<i '.$css_i_inline.' class="'.esc_html($button_icon).'"></i>';
				\Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true', 'style' => $css_i_inline ] );
			}				
					
			echo esc_html($button_text) . '</a>';
		echo '</span>';	
		

		
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {}
}
