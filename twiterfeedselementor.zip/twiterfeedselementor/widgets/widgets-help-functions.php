<?php
/** Get Animations **/
if(!function_exists('tfe_animate_class')) {
	function tfe_animate_class($addon_animate,$effect,$delay) {
		if($addon_animate == 'on') : 
			wp_enqueue_script( 'appear' );			
			wp_enqueue_script( 'animate' );		
			$animate_class = ' animate-in" data-anim-type="'.$effect.'" data-anim-delay="'.$delay.'"'; 
		else :
			$animate_class = '"';
		endif;		
		return $animate_class;
	}
}

//convert links to clickable format
if (!function_exists('tfe_convert_links')) {
	function tfe_convert_links($status,$targetBlank=true){
	 
		// the target
			$target=$targetBlank ? " target=\"_blank\" " : "";
		 
		// convert link to url								
			$status = preg_replace('/\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[A-Z0-9+&@#\/%=~_|]/i', '<a href="\0" target="_blank">\0</a>', $status);
		 
		// convert @ to follow
			$status = preg_replace("/(@([_a-z0-9\-]+))/i","<a href=\"http://twitter.com/$2\" title=\"Follow $2\" $target >$1</a>",$status);
		 
		// convert # to search
			$status = preg_replace("/(#([_a-z0-9\-]+))/i","<a href=\"https://twitter.com/search?q=$2\" title=\"Search $1\" $target >$1</a>",$status);
		 
		// return the status
		return $status;
	}
}

//convert dates to readable format	
if (!function_exists('tfe_date_time')) {
	function tfe_date_time($a) {
		//get current timestampt
		$b = strtotime('now'); 
		//get timestamp when tweet created
		$c = strtotime($a);
		//get difference
		$d = $b - $c;
		//calculate different time values
		$minute = 60;
		$hour = $minute * 60;
		$day = $hour * 24;
		$week = $day * 7;
			
		if(is_numeric($d) && $d > 0) {
			//if less then 3 seconds
			if($d < 3) return esc_html__('right now','twitterfeedselementor');
			//if less then minute
			if($d < $minute) return floor($d) . esc_html__(' seconds ago','twitterfeedselementor');
			//if less then 2 minutes
			if($d < $minute * 2) return esc_html__('about 1 minute ago','twitterfeedselementor');
			//if less then hour
			if($d < $hour) return floor($d / $minute) . esc_html__(' minutes ago','twitterfeedselementor');
			//if less then 2 hours
			if($d < $hour * 2) return esc_html__('about 1 hour ago','twitterfeedselementor');
			//if less then day
			if($d < $day) return floor($d / $hour) . esc_html__(' hours ago','twitterfeedselementor');
			//if more then day, but less then 2 days
			if($d > $day && $d < $day * 2) return esc_html__('yesterday','twitterfeedselementor');
			//if less then year
			if($d < $day * 365) return floor($d / $day) . esc_html__(' days ago','twitterfeedselementor');
			//else return more than a year
			return esc_html__('over a year ago','twitterfeedselementor');
		}
	}	
}