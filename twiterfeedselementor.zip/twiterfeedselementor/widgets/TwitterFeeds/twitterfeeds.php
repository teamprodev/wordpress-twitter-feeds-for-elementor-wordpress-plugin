<?php
namespace ElementorTwitterFeeds\Widgets;

use \Elementor\Controls_Manager as Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Group_Control_Border as Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow as Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography as Group_Control_Typography;
use \Elementor\Utils as Utils;
use \Elementor\Widget_Base as Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor TwitterFeeds
 *
 * Elementor widget for team vision
 *
 * @since 1.0.0
 */
class TwitterFeeds extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twitter-feed-elementor';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Twitter Feeds', 'twitterfeedselementor' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-share';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twitterfeedselementor' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Twitter Feed', 'twitterfeedselementor' ),
			]
		);

		$this->add_control(
			'username',
			[
				'label' => esc_html__( 'Username', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'info',
			[
				'label' => esc_html__( 'Get your API keys &amp; tokens at:<br /><a href="https://apps.twitter.com/" target="_blank">https://apps.twitter.com/</a>', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'consumerkey',
			[
				'label' => esc_html__( 'Consumer key', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'consumersecret',
			[
				'label' => esc_html__( 'Consumer Secret', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'accesstoken',
			[
				'label' => esc_html__( 'Access Token', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'accesstokensecret',
			[
				'label' => esc_html__( 'Access Token Secret', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'tweetstoshow',
			[
				'label' => esc_html__( 'Tweets to show', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'hashtag',
			[
				'label' => esc_html__( 'Hashtag', 'twitterfeedselementor' ),
				'description' => esc_html( 'Leave Empty for all hashtags', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'excludereplies',
			[
				'label' => esc_html__( 'Exclude replies', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'twitterfeedselementor' ),
				'label_off' => esc_html__( 'Off', 'twitterfeedselementor' ),
				'return_value' => 'yes',
				'default' => false,
			]
		);

		$this->add_control(
			'full_text',
			[
				'label' => esc_html__( 'Tweets Length', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'full',
				'options' => [
					'full'		=> esc_html__( 'Full Text', 'twitterfeedselementor' ),
					'truncate' 	=> esc_html__( 'Truncate', 'twitterfeedselementor' )
				]
			]
		);

		$this->add_control(
			'type',
			[
				'label' => esc_html__( 'Type', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'slide',
				'options' => [
					'slide'		=> esc_html__( 'Slide', 'twitterfeedselementor' ),
					'timeline' 	=> esc_html__( 'Timeline', 'twitterfeedselementor' ),
					'normal' 	=> esc_html__( 'Normal', 'twitterfeedselementor' ),
				]
			]
		);

		$this->end_controls_section();

  		$this->start_controls_section(
  			'section_settings',
  			[
  				'label' => esc_html__( 'Settings', 'twitterfeedselementor' )
  			]
		);

		$this->add_control(
			'loop',
			[
				'label' => esc_html__( 'Loop', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'true',
				'options' => [
					'true' 		=> esc_html__( 'On', 'twitterfeedselementor' ),
					'false' 	=> esc_html__( 'Off', 'twitterfeedselementor' )
				],
				'condition'	=> [
					'type'	=> 'slide'
				]
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay (ms) - ex 2000 or leave empty for default', 'twitterfeedselementor' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => '2000',
				'condition'	=> [
					'type'	=> 'slide'
				]
			]
		);

		$this->add_control(
			'smart_speed',
			[
				'label' => esc_html__( 'Speed (ms) - ex 2000 or leave empty for default', 'twitterfeedselementor' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => '2000',
				'condition'	=> [
					'type'	=> 'slide'
				]
			]
		);

		$this->add_control(
			'rtl',
			[
				'label' => esc_html__( 'RTL', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'false',
				'options' => [
					'true' 		=> esc_html__( 'On', 'twitterfeedselementor' ),
					'false' 	=> esc_html__( 'Off', 'twitterfeedselementor' )
				],
				'condition'	=> [
					'type'	=> 'slide'
				]
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style', 'twitterfeedselementor' ),
			]
		);


		$this->add_control(
			'border_type',
			[
				'label' => esc_html__( 'Border Type', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'square',
				'options' => [
					'square'		=> esc_html__( 'Square', 'twitterfeedselementor' ),
					'round' 	=> esc_html__( 'Round', 'twitterfeedselementor' ),
				]
			]
		);

		$this->add_control(
			'custom_color',
			[
				'label' => esc_html__( 'Custom Color', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'off',
				'options' => [
					'off'	=> 'Off',
					'on' 	=> 'On'
				]
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background Color Twitter', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#f9f9f9',
				'condition'	=> [
					'custom_color'	=> 'on'
				]
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color Twitter', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#777777',
				'condition'	=> [
					'custom_color'	=> 'on'
				]
			]
		);


		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color Twitter', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#B4B4B4',
				'condition'	=> [
					'custom_color'	=> 'on'
				]
			]
		);


		$this->add_control(
			'background_icon',
			[
				'label' => esc_html__( 'Background Color Icone', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#6ec1e4',
				'condition'	=> [
					'type'	=> 'timeline',
					'custom_color'	=> 'on'
				]
			]
		);


		$this->add_control(
			'color_icon',
			[
				'label' => esc_html__( 'Color Icon', 'twitterfeedselementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'condition'	=> [
					'type'	=> 'timeline',
					'custom_color'	=> 'on'
				]
			]
		);


		$this->end_controls_section();



		$this->start_controls_section(
			'section_animation',
			[
				'label' => esc_html__( 'Animations', 'twitterfeedselementor' )
			]
		);

		$this->add_control(
			'addon_animate',
			[
				'label' => esc_html__( 'Animate', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'off',
				'options' => [
					'off'	=> 'Off',
					'on' 	=> 'On'
				]
			]
		);

		$this->add_control(
			'effect',
			[
				'label' => esc_html__( 'Animate Effects', 'twitterfeedselementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'fade-in',
				'options' => [
							'fade-in'			=> esc_html__( 'Fade In', 'twitterfeedselementor' ),
							'fade-in-up' 		=> esc_html__( 'fade in up', 'twitterfeedselementor' ),
							'fade-in-down' 		=> esc_html__( 'fade in down', 'twitterfeedselementor' ),
							'fade-in-left' 		=> esc_html__( 'fade in Left', 'twitterfeedselementor' ),
							'fade-in-right' 	=> esc_html__( 'fade in Right', 'twitterfeedselementor' ),
							'fade-out'			=> esc_html__( 'Fade In', 'twitterfeedselementor' ),
							'fade-out-up' 		=> esc_html__( 'Fade Out up', 'twitterfeedselementor' ),
							'fade-out-down' 	=> esc_html__( 'Fade Out down', 'twitterfeedselementor' ),
							'fade-out-left' 	=> esc_html__( 'Fade Out Left', 'twitterfeedselementor' ),
							'fade-out-right' 	=> esc_html__( 'Fade Out Right', 'twitterfeedselementor' ),
							'bounce-in'			=> esc_html__( 'Bounce In', 'twitterfeedselementor' ),
							'bounce-in-up' 		=> esc_html__( 'Bounce in up', 'twitterfeedselementor' ),
							'bounce-in-down' 	=> esc_html__( 'Bounce in down', 'twitterfeedselementor' ),
							'bounce-in-left' 	=> esc_html__( 'Bounce in Left', 'twitterfeedselementor' ),
							'bounce-in-right' 	=> esc_html__( 'Bounce in Right', 'twitterfeedselementor' ),
							'bounce-out'		=> esc_html__( 'Bounce In', 'twitterfeedselementor' ),
							'bounce-out-up' 	=> esc_html__( 'Bounce Out up', 'twitterfeedselementor' ),
							'bounce-out-down' 	=> esc_html__( 'Bounce Out down', 'twitterfeedselementor' ),
							'bounce-out-left' 	=> esc_html__( 'Bounce Out Left', 'twitterfeedselementor' ),
							'bounce-out-right' 	=> esc_html__( 'Bounce Out Right', 'twitterfeedselementor' ),
							'zoom-in'			=> esc_html__( 'Zoom In', 'twitterfeedselementor' ),
							'zoom-in-up' 		=> esc_html__( 'Zoom in up', 'twitterfeedselementor' ),
							'zoom-in-down' 		=> esc_html__( 'Zoom in down', 'twitterfeedselementor' ),
							'zoom-in-left' 		=> esc_html__( 'Zoom in Left', 'twitterfeedselementor' ),
							'zoom-in-right' 	=> esc_html__( 'Zoom in Right', 'twitterfeedselementor' ),
							'zoom-out'			=> esc_html__( 'Zoom In', 'twitterfeedselementor' ),
							'zoom-out-up' 		=> esc_html__( 'Zoom Out up', 'twitterfeedselementor' ),
							'zoom-out-down' 	=> esc_html__( 'Zoom Out down', 'twitterfeedselementor' ),
							'zoom-out-left' 	=> esc_html__( 'Zoom Out Left', 'twitterfeedselementor' ),
							'zoom-out-right' 	=> esc_html__( 'Zoom Out Right', 'twitterfeedselementor' ),
							'flash' 			=> esc_html__( 'Flash', 'twitterfeedselementor' ),
							'strobe'			=> esc_html__( 'Strobe', 'twitterfeedselementor' ),
							'shake-x'			=> esc_html__( 'Shake X', 'twitterfeedselementor' ),
							'shake-y'			=> esc_html__( 'Shake Y', 'twitterfeedselementor' ),
							'bounce' 			=> esc_html__( 'Bounce', 'twitterfeedselementor' ),
							'tada'				=> esc_html__( 'Tada', 'twitterfeedselementor' ),
							'rubber-band'		=> esc_html__( 'Rubber Band', 'twitterfeedselementor' ),
							'swing' 			=> esc_html__( 'Swing', 'twitterfeedselementor' ),
							'spin'				=> esc_html__( 'Spin', 'twitterfeedselementor' ),
							'spin-reverse'		=> esc_html__( 'Spin Reverse', 'twitterfeedselementor' ),
							'slingshot'			=> esc_html__( 'Slingshot', 'twitterfeedselementor' ),
							'slingshot-reverse'	=> esc_html__( 'Slingshot Reverse', 'twitterfeedselementor' ),
							'wobble'			=> esc_html__( 'Wobble', 'twitterfeedselementor' ),
							'pulse' 			=> esc_html__( 'Pulse', 'twitterfeedselementor' ),
							'pulsate'			=> esc_html__( 'Pulsate', 'twitterfeedselementor' ),
							'heartbeat'			=> esc_html__( 'Heartbeat', 'twitterfeedselementor' ),
							'panic' 			=> esc_html__( 'Panic', 'twitterfeedselementor' )
				],
				'condition'	=> [
					'addon_animate'	=> 'on'
				]
			]
		);

		$this->add_control(
			'delay',
			[
				'label' => esc_html__( 'Animate Delay (ms)', 'twitterfeedselementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => '1000',
				'condition'	=> [
					'addon_animate'	=> 'on'
				]
			]
		);

		$this->end_controls_section();

}



	 /**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		static $instance = 0;
		$instance++;
		$settings 				= $this->get_settings_for_display();

		$username				= esc_html($settings['username']);
		$consumerkey			= esc_html($settings['consumerkey']);
		$consumersecret			= esc_html($settings['consumersecret']);
		$accesstoken			= esc_html($settings['accesstoken']);
		$accesstokensecret		= esc_html($settings['accesstokensecret']);
		$tweetstoshow			= esc_html($settings['tweetstoshow']);
		$excludereplies			= esc_html($settings['excludereplies']);
		$full_text				= esc_html($settings['full_text']);
		$hashtag				= esc_html($settings['hashtag']);
		$type					= esc_html($settings['type']);
		$loop					= esc_html($settings['loop']);
		$autoplay				= esc_html($settings['autoplay']);
		$smart_speed			= esc_html($settings['smart_speed']);
		$rtl					= esc_html($settings['rtl']);
		$border_color			= esc_html($settings['border_color']);
		$custom_color			= esc_html($settings['custom_color']);
		$background_color		= esc_html($settings['background_color']);
		$title_color			= esc_html($settings['title_color']);
		$rtl					= esc_html($settings['rtl']);
		$border_type			= esc_html($settings['border_type']);
		$background_icon		= esc_html($settings['background_icon']);
		$color_icon				= esc_html($settings['color_icon']);




		// Animations
		$addon_animate				= esc_html($settings['addon_animate']);
		$effect								= esc_html($settings['effect']);
		$delay								= esc_html($settings['delay']);

		wp_enqueue_script( 'appear' );
		wp_enqueue_script( 'animate' );
		wp_enqueue_style( 'animations' );
		wp_enqueue_style( 'tfe-style' );

		$title = get_the_title();
		$url = get_the_permalink();

		function getConnectionWithAccessToken($cons_key, $cons_secret, $oauth_token, $oauth_token_secret) {
		  $connection = new \TwitterOAuth($cons_key, $cons_secret, $oauth_token, $oauth_token_secret);
		  return $connection;
		}

		$connection = getConnectionWithAccessToken($consumerkey, $consumersecret, $accesstoken, $accesstokensecret);
		if($full_text == 'full') {
			$tweets = $connection->get("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=".$username."&count=".$tweetstoshow."&tweet_mode=extended&exclude_replies=".$excludereplies) or die(esc_html__('Couldn\'t retrieve tweets! Wrong username?','twitterfeedselementor'));
		} else {
			$tweets = $connection->get("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=".$username."&count=".$tweetstoshow."&exclude_replies=".$excludereplies) or die(esc_html__('Couldn\'t retrieve tweets! Wrong username?','twitterfeedselementor'));
		}
		if(!empty($tweets->errors)){
			if($tweets->errors[0]->message == 'Invalid or expired token'){
				echo '<strong>'.$tweets->errors[0]->message.'!</strong><br />' . esc_html__('You\'ll need to regenerate it <a href="https://apps.twitter.com/" target="_blank">here</a>!','twitterfeedselementor') . $after_widget;
			}else{
				echo '<strong>'.$tweets->errors[0]->message.'</strong>' . $after_widget;
			}
			return;
		}

		$tweets_array = array();

		if(empty($hashtag) || $hashtag == '') {
			
			for($i = 0;$i <= count($tweets); $i++){
				if(!empty($tweets[$i])){				
						$tweets_array[$i]['created_at'] = $tweets[$i]->created_at;

						if($full_text == 'full') { $text_length = $tweets[$i]->full_text; } else { $text_length = $tweets[$i]->text; }
						$tweets_array[$i]['text'] = preg_replace('/[\x{10000}-\x{10FFFF}]/u', '', $text_length);

						if(!empty($tweets[$i]->id_str)){
							$tweets_array[$i]['status_id'] = $tweets[$i]->id_str;
						}

						$tweets_array[$i]['hashtags'] = $tweets[$i]->entities->hashtags;
						$tweets_array[$i]['entities'] = $tweets[$i]->entities;
				} 
			} 
			
		} else {
			
			for($i = 0;$i <= count($tweets); $i++){
				if(!empty($tweets[$i])){				
					if(array_search($hashtag, array_column($tweets[$i]->entities->hashtags, 'text'))) {
						
						$tweets_array[$i]['created_at'] = $tweets[$i]->created_at;

						if($full_text == 'full') { $text_length = $tweets[$i]->full_text; } else { $text_length = $tweets[$i]->text; }
						$tweets_array[$i]['text'] = preg_replace('/[\x{10000}-\x{10FFFF}]/u', '', $text_length);

						if(!empty($tweets[$i]->id_str)){
							$tweets_array[$i]['status_id'] = $tweets[$i]->id_str;
						}

						$tweets_array[$i]['hashtags'] = $tweets[$i]->entities->hashtags;
						$tweets_array[$i]['entities'] = $tweets[$i]->entities;					
					}	
				} 
			} 
			
		}	

		$tweets_array = maybe_unserialize($tweets_array);

		if($type == 'slide') {
			wp_enqueue_style( 'owlcarousel' );
			wp_enqueue_style( 'owltheme' );
			wp_enqueue_script( 'owlcarousel' );
			wp_enqueue_script( 'tfe-slide' );
			wp_enqueue_style( 'tfe-style' );

			$output = '<div data-twitter-feeds-elementor-owl-items="1"
							data-twitter-feeds-elementor-owl-items-900="1"
							data-twitter-feeds-elementor-owl-items-600="1"
							data-twitter-feeds-elementor-owl-loop="'.esc_html($loop).'"
							data-twitter-feeds-elementor-owl-autoplay="'.esc_html($autoplay).'"
							data-twitter-feeds-elementor-owl-smart-speed="'.esc_html($smart_speed).'"
							data-twitter-feeds-elementor-owl-navigation="false"
							data-twitter-feeds-elementor-owl-pagination="false"
							data-twitter-feeds-elementor-owl-rtl="'.esc_html($rtl).'"
							class="tfe-slide tfe-slide-owl-carousel tfe-slide-carousel tfe-slide-carousel-'.esc_html($instance).'">';

				foreach ( $tweets_array as $tweet ) {
					$output .= '<div class="tfe-slide-item-' . esc_html($instance) . tfe_animate_class($addon_animate,$effect,$delay) . '">';
						$output .= '<div class="tfe-slide-carousel-container '.$border_type.'" style="background:'. $settings['background_color'] .'; border-color:'.$settings['border_color'] .'">';
							$output .= '<span  style="color:'. $settings['title_color'] .'">'.tfe_convert_links($tweet['text']).'</span><a class="twitter_time" target="_blank" href="http://twitter.com/'.$username.'/statuses/'.$tweet['status_id'].'">'.tfe_date_time($tweet['created_at']).'</a>';
						$output .= '</div>';
					$output .= '</div>';
				}

			$output .= '</div>';

		} elseif ($type == 'timeline') {

			wp_enqueue_script( 'tfe-slide' );
			wp_enqueue_style( 'tfe-style' );
			wp_enqueue_style( 'elementor-icons' );
			wp_enqueue_style( 'font-awesome' );

			$output = '<div class="tfe-timeline tfe-timeline-'.esc_html($instance).' timeline-style1">';

				$output .= '<section class="timeline-container">';

	         foreach ( $tweets_array as $tweet ) {

								$output .= '<div class="tfe-timeline-block'.tfe_animate_class($addon_animate,$effect,$delay).'>';

									$output .= '<div class="tfe-timeline-img">';
										$output .= '<div class="tfe-timeline-img">';
											$output .= '<div class="timeline_format_icon timeline timeline-icon">';
												$output .= '<span class="fa fas fa-twitter '.$border_type.'" style="background:'. $settings['background_icon'] .'; color:'.$settings['color_icon'] .' ">';
												$output .= '</span>';
											$output .= '</div>';
										$output .= '</div>';
									$output .= '</div>';

									$output .= '<div class="tfe-timeline-content '.$border_type.'" style="background:'. $settings['background_color'] .'; border-color:'.$settings['border_color'] .' ">';
										if(isset($tweet['entities']->media)) {
											$output .= '<div class="tfe-timeline-image">';

												$output .= '<a href="http://twitter.com/'.$username.'/statuses/'.$tweet['status_id'].'"><img src="'.$tweet['entities']->media[0]->media_url_https.'" alt="" ></a>';

												$output .= '';
											$output .= '</div>';
										}
										$output .= '<div class="tfe-timeline-text"  style="color:'. $settings['title_color'] .'">';
											$output .= '<div class="info">';
													$output .= $username;
											$output .= '</div>';
												$output .= tfe_convert_links($tweet['text']);
												$output .= '<a href="http://twitter.com/'.$username.'/statuses/'.$tweet['status_id'].'">'.esc_html__('Go to tweet','twitterfeedselementor').'</a>';
										$output .= '</div>';
										$output .= '<span class="timeline-date"  style="color:'. $settings['title_color'] .'">';
											$output .= tfe_date_time($tweet['created_at']);
										$output .= '</span>';
									$output .= '</div>';



								$output .= '</div>';

							}

				$output .= '</section>';
			$output .= '<div class="timeline-clear"></div>';
			$output .= '</div>';


		} elseif ($type == 'normal') {


			wp_enqueue_style( 'owltheme' );
			wp_enqueue_style( 'tfe-style' );


			$output = '<div	class="tfe-normal tfe-normal-'.esc_html($instance).'">';

			foreach ( $tweets_array as $tweet ) {
				$output .= '<div class="tfe-item' . tfe_animate_class($addon_animate,$effect,$delay) . '">';
					$output .= '<div class="tfe-box '.$border_type.'" style="background:'. $settings['background_color'] .'; border-color:'.$settings['border_color'] .'">';
						$output .= '<span  style="color:'. $settings['title_color'] .'">'.tfe_convert_links($tweet['text']).'</span><a class="twitter_time" target="_blank" href="http://twitter.com/'.$username.'/statuses/'.$tweet['status_id'].'">'.tfe_date_time($tweet['created_at']).'</a>';
					$output .= '</div>';
				$output .= '</div>';
		  }

		  $output .= '</div>';



		}

		echo $output;
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {}
}
