/*
 * Twitter Feeds for Elementor
 */
 
 jQuery(document).ready(function($){
	"use strict"; 

    $('.tfe-slide-owl-carousel').each( function() {
        var $carousel = $(this);
        $carousel.owlCarousel({
			dots : $carousel.data("twitter-feeds-elementor-owl-pagination"),
			nav : $carousel.data("twitter-feeds-elementor-owl-navigation"),
			rtl : $carousel.data("twitter-feeds-elementor-owl-rtl"),
			loop: $carousel.data("twitter-feeds-elementor-owl-loop"),
			smartSpeed: $carousel.data("twitter-feeds-elementor-owl-smart-speed"),
			autoplay : true,
			autoplayTimeout : $carousel.data("twitter-feeds-elementor-owl-autoplay"),
			navText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
			responsive:{
				0:{
					items: $carousel.data("twitter-feeds-elementor-owl-items")
				},
				600:{
					items: $carousel.data("twitter-feeds-elementor-owl-items")
				},
				1000:{
					items: $carousel.data("twitter-feeds-elementor-owl-items")
				}
			}			
        });
    });	

 });
 
 var TfeSlideHandler = function($scope, $) {

    $('.tfe-slide-owl-carousel').each( function() {
        var $carousel = $(this);
        $carousel.owlCarousel({
			dots : $carousel.data("twitter-feeds-elementor-owl-pagination"),
			nav : $carousel.data("twitter-feeds-elementor-owl-navigation"),
			rtl : $carousel.data("twitter-feeds-elementor-owl-rtl"),
			loop: $carousel.data("twitter-feeds-elementor-owl-loop"),
			smartSpeed: $carousel.data("twitter-feeds-elementor-owl-smart-speed"),
			autoplay : true,
			autoplayTimeout : $carousel.data("twitter-feeds-elementor-owl-autoplay"),
			navText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
			responsive:{
				0:{
					items: $carousel.data("twitter-feeds-elementor-owl-items")
				},
				600:{
					items: $carousel.data("twitter-feeds-elementor-owl-items")
				},
				1000:{
					items: $carousel.data("twitter-feeds-elementor-owl-items")
				}
			}			
        });
    });	
};	
 
 jQuery(window).on("elementor/frontend/init", function() {
	"use strict";
    elementorFrontend.hooks.addAction(
        "frontend/element_ready/twitter-feed-elementor.default",
		 TfeSlideHandler
    );
});	