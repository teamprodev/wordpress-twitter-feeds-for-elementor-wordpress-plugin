<?php
namespace Creativetable;

use Creativetable\PageSettings\Page_Settings;
define( "bwdct_ASFSK_ASSETS_PUBLIC_DIR_FILE", plugin_dir_url( __FILE__ ) . "assets/public" );
define( "bwdct_ASFSK_ASSETS_ADMIN_DIR_FILE", plugin_dir_url( __FILE__ ) . "assets/admin" );
class ClassbwdctCreativeTable {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function bwdct_admin_editor_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'bwdct_admin_editor_scripts_as_a_module' ], 10, 2 );
	}

	public function bwdct_admin_editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'bwdct_creative_table_editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/bwdct-creativeTable.php' );
	}

	public function bwdct_register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register WidgetsF
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\bwdct_creativetable());
	}

	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/bwdct-creativetable-manager.php' );
		new Page_Settings();
	}

	// Register Category
	function bwdct_add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'bwdct-creative-table-category',
			[
				'title' => esc_html__( 'Data Table', 'bwdct-creative-table' ),
				'icon' => 'eicon-person',
			]
		);
	}
	public function bwdct_all_assets_for_the_public(){
		$all_css_js_file = array(

            'creativetable-plugin-main-style' => array('bwdct_path_define'=>bwdct_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/main.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['bwdct_path_define'], null, '1.3', 'all');
        }
	}

	public function bwdct_all_assets_for_elementor_editor_admin(){
		$all_css_js_file = array(
            'creativetable-admin-main-style' => array('bwdct_path_admin_define'=>bwdct_ASFSK_ASSETS_ADMIN_DIR_FILE . '/icon.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['bwdct_path_admin_define'], null, '1.3', 'all');
        }
	}
	
	public function __construct() {

		// For public assets
		add_action('wp_enqueue_scripts', [$this, 'bwdct_all_assets_for_the_public']);

		// For Elementor Editor
		add_action('elementor/editor/before_enqueue_scripts', [$this, 'bwdct_all_assets_for_elementor_editor_admin']);
		
		// Register Category
		add_action( 'elementor/elements/categories_registered', [ $this, 'bwdct_add_elementor_widget_categories' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'bwdct_register_widgets' ] );

		// Register editor scripts
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'bwdct_admin_editor_scripts' ] );
		
		$this->add_page_settings_controls();
	}
}

// Instantiate Plugin Class
Classbwdctcreativetable::instance();